#include "a.h"
#include "afunix_udp.h"
#include "dispose.h"
#include "dealcmd.h"

#include <math.h>


#define MAX_PATH 260
#define CONF_FILE_PATH	"Config.ini"
#define GPIO_NUM 23

#define SERIAL_DEVICE "/dev/ttymxc1"

//////////////////////////////////

//启动主程序
int main()
{
    printf("version=1.01\n");
    fn_v4l2_init();
    //启动服务
    int serverfd = s_init_net(SCANQR_PATH_S);
    if (serverfd<=0)
    {
         printf("serverfd init error:%d",serverfd);
         return -1;
    }
    //循环接收命令
    fn_dispose(serverfd);
    //关闭网络
    close_net(serverfd,SCANQR_PATH_S);
    return 0;
}
