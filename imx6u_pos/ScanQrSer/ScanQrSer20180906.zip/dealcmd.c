#include "dealcmd.h"
#include "v4l2uvc.h"
#include "zbar_cut.h"
#include "a.h"


video_t v = {
	.dev_name = v4l_dev,
	.width = 800,
	.height = 600,
	.pixelformat = V4L2_PIX_FMT_YUYV,//V4L2_PIX_FMT_MJPEG,
};

void fn_v4l2_init()
{
    v4l2_init(&v);
}

//通过v4l2_put_mem和v4l2_get_mem，获取一帧图像
static int _cams_cap_image()
{
	video_t *vp = &v;
	int ret;
	ret = v4l2_get_mem(&v);
	if (ret < 0) {
		return ret;
	}
	////////////////////////////////////////////////////////
    //填写my_v并返回 modified by yangtao 20108-08-16
    my_v.width=vp->width;
    my_v.height=vp->height;
	if (vp->pixelformat == V4L2_PIX_FMT_MJPEG) {
		my_v.fmt = PIX_FMT_MJPEG;
	} else if (vp->pixelformat == V4L2_PIX_FMT_YUYV) {
		my_v.fmt = PIX_FMT_YUYV;
	}
	my_v.len=vp->buf.bytesused;
	my_v.bufindex=vp->buf.index;
	my_v.buf=malloc(my_v.len);
	memcpy(my_v.buf,vp->mem[vp->buf.index],vp->buf.bytesused);
    ////////////////////////////////////////////////////////
    //printf("get mem:width=%d,heigth=%d,fmt=%d\n",my_v.width,my_v.height,my_v.fmt);
	if (ret < 0)
	{
		return ret;
	}
  	ret = v4l2_put_mem(&v);
	if (ret < 0) {
		return ret;
	}
	return 0;
}

//抓图并解码
char * cams_qr_decode(int * codelen)
{
	video_t *vp = &v;
	char * ret_buf = NULL;
	int len = 0;
	//首先抓取一张图
	if (_cams_cap_image() < 0) {
		return NULL;
	}
	printf("decode:get image\n");
	////////////////////////////////////////////////////////////////////////////
	void *buf = malloc(vp->buf.bytesused + sizeof(qr_data_t));
    memset(buf,0,vp->buf.bytesused + sizeof(qr_data_t));
	if(zbar_decode(my_v.width, my_v.height, (u8 *)my_v.buf, my_v.len, 0, (qr_data_t *)buf)==1)
	{
	    len = strlen(((qr_data_t *)buf)->data)+1;
	    ret_buf = (char *)malloc(len);
	    memcpy(ret_buf,((qr_data_t *)buf)->data,len);
	    printf("qr:%s\n",((qr_data_t *)buf)->data);
	}
	////////////////////////////////////////////////////////////////////////////
	printf("cams_qr_decode OK!\n");
	free(my_v.buf);
	free(buf);
	*codelen = len;
	return ret_buf;
}

//处理函数 开始捕获
char * fn_dealCmd_BeginCap(char * recv_buf,int recv_len,int * ret_len)
{
    //开始
    v4l2_on(&v);
    //返回
    ret_len = 0;
    return NULL;
}

//处理函数 扫码
char * fn_dealCmd_GetQRCode(char * recv_buf,int recv_len,int * ret_len)
{
    char * ret_buf = cams_qr_decode(ret_len);
    //返回
    return ret_buf;
}

//处理函数 停止捕获
char * fn_dealCmd_EndCap(char * recv_buf,int recv_len,int * ret_len)
{
    //结束
    v4l2_off(&v);
    //返回
    ret_len = 0;
    return NULL;
}
