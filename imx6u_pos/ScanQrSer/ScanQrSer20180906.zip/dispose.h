#ifndef DISPOSE_H
#define DISPOSE_H

#include "a.h"

void fn_dispose(int servfd);

#endif // DISPOSE_H
