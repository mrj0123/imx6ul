#include "afunix_udp.h"
#include "sockfile.h"

#define SEND_BODY 8888

//客户端初始化
int c_init_net(char cli_path[108])
{
    int client_fd = unsock_server_init(cli_path);
    return client_fd;
}

//服务端初始化
int s_init_net(char ser_path[108])
{
    int server_fd = unsock_server_init(ser_path);
    return server_fd;
}
//关闭服务端连接，清楚通讯文件
int close_net(int fd,char path[108])
{
    close(fd);
    unlink(path);
    return 0;
}

char * recv_packet(cmd_head_t * pHead,int fd,struct sockaddr_un * src_addr,socklen_t * addrlen)
{
    int ret;
    size_t n;
    //分配包头空间
    //cmd_head_t * pHead = (cmd_head_t *)malloc(sizeof(cmd_head_t));
    if (pHead == NULL)
    {
        printf("head error!\n");
        return NULL;
    }
    memset(pHead,0,sizeof(cmd_head_t));
    n = sizeof(cmd_head_t);
    printf("sizeof(cmd_head_t)=%d\n",n);
    //接收包头
    //////////////////////////////////////////////////////////////////////////////////
    ret = unsock_server_recvfrom(fd, (struct sockaddr *)src_addr, addrlen, pHead, n , 10000);
    ///////////////////////////////////////////////
    printf("recvhead:cmd=%d,length=%d\n",pHead->cmd,pHead->length);
    ///////////////////////////////////////////////
    if (ret != (int)n) {
        //如果未能成功接受包头，返回错误
        printf("recv head error %d %d\n", ret, n);
        return NULL;
    }
    if (pHead->length>0) {
        //根据包身长度重新分配包空间
        char * recvbuf =(char *) malloc(pHead->length);
        //重新分配空间失败，返回
        if (recvbuf == NULL)
        {
            printf("malloc pack data error!\n");
            return NULL;
        }
        n = pHead->length;
        printf("sockaddr=%s\n",src_addr->sun_path);

        //请求发送包身
        printf("send answer:\n");
        cmd_head_t head;
        head.cmd = SEND_BODY;
        head.length = 0;
        usleep(10000);
        ret = unsock_server_sendto(fd, (struct sockaddr *)src_addr, addrlen, &head, sizeof(cmd_head_t));
        printf("send answer over %d\n",ret);
        if (ret<0)
        {
            return NULL;
        }
        //接收包身
        ///////////////////////////////////////////////////////////////
        ret = unsock_server_recvfrom(fd, (struct sockaddr *)src_addr, addrlen, recvbuf, n , 10000);
        ///////////////////////////////////////////////
        printf("recvdata:");
        for(int i=0;i<(int)n;i++)
        {
            printf("%02X",*((char *)(recvbuf + sizeof(cmd_head_t)+i)));
        }
        printf("\n");
        ///////////////////////////////////////////////
        if (ret != (int)n) {
            //包身接收失败，返回
            printf("recv data error %d\n", ret);
            return NULL;
        }
        printf("recv data OK!\n");
        return recvbuf;
    }
    else
    {
        return NULL;
    }
}

//发送数据包，需要目的地址。客户端的目的地址是c_init_net返回的ser_addr，服务器端目的地址是s_recv_packet返回的cli_addr
int s_send_packet(int fd, int cmd, u8 *buf, size_t n ,struct sockaddr_un * dst_addr,socklen_t * addrlen)
{
    printf("send packet start!!!!\n");
    cmd_head_t * pHead = (cmd_head_t *)malloc(sizeof(cmd_head_t));
    pHead->cmd = cmd;
    pHead->length = n;
    printf("send packet!\n");

    //int ret = sendto(fd, phead, sizeof(cmd_head_t), 0, (struct sockaddr *)dst_addr, len);
    int ret = unsock_server_sendto(fd, (struct sockaddr *)dst_addr, addrlen, pHead, sizeof(cmd_head_t));
    if (ret < 0 )
    {
        printf("send packet error ret=%d!",ret);
        free(pHead);
        return -1;
    }
    //如果只发包头，返回
    if (buf==NULL || n==0)
    {
        free(pHead);
        return ret;
    }
    printf("client:send head OK!");

    //接收返回确认数据
    //ret = recvfrom(fd, phead, sizeof(cmd_head_t) , 0 ,  (struct sockaddr *)dst_addr , &len);
    ret = unsock_server_recvfrom(fd, (struct sockaddr *)dst_addr, addrlen, pHead, sizeof(cmd_head_t),10000);
    if (pHead->cmd != SEND_BODY)
    {
        free(pHead);
        return -2;
    }

    free(pHead);
    //发送包身
    //ret = sendto(fd, buf, n, 0, (struct sockaddr *)dst_addr, len);
    ret = unsock_server_sendto(fd, (struct sockaddr *)dst_addr, addrlen, buf, n);
    if (ret < 0 )
    {
        return -3;
    }
    ///////////////////////////////////////////////
    printf("send packet over!!!!\n");
    return ret;
}

//客户端发送数据包，需要服务器段路径作为目的地址
int c_send_packet(int fd, int cmd, u8 *buf, size_t n ,char ser_path[108])
{
    printf("send packet start!");
    cmd_head_t * pHead = (cmd_head_t *)malloc(sizeof(cmd_head_t));
    pHead->cmd = cmd;
    pHead->length = n;

    int ret = unsock_client_sendto(fd, pHead, sizeof(cmd_head_t),ser_path);
    if (ret < 0 )
    {
        printf("send packet error ret=%d!",ret);
        free(pHead);
        return -1;
    }
    //如果只发包头，返回
    if (buf==NULL || n==0)
    {
        free(pHead);
        return ret;
    }


    //接收返回确认数据
    //ret = recvfrom(fd, phead, sizeof(cmd_head_t) , 0 ,  (struct sockaddr *)dst_addr , &len);
    struct sockaddr_un src_addr;
    socklen_t addrlen=sizeof(src_addr);
    memset(&src_addr,0,addrlen);
    ret = unsock_server_recvfrom(fd, (struct sockaddr *)&src_addr, &addrlen, pHead, sizeof(cmd_head_t),10000);
    if (pHead->cmd != SEND_BODY)
    {
        free(pHead);
        return -2;
    }

    free(pHead);

    //发送包身
    //ret = sendto(fd, buf, n, 0, (struct sockaddr *)dst_addr, len);
    ret = unsock_client_sendto(fd, buf, n, ser_path);
    if (ret < 0 )
    {
        return -3;
    }
    ///////////////////////////////////////////////
    printf("send packet over!\n");
    return ret;
}
